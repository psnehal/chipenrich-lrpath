library(testthat)
library(chipenrich)

test_check("chipenrich")
